# Definición de la clase principal para el proyecto
class HerramientaAlquiler:
    # Constructor de la clase con atributos privados
    def __init__(self, nombre, precio_dia):
        self.__nombre = nombre  # Nombre de la herramienta
        self.__precio_dia = precio_dia  # Precio por jornada

    # Método para calcular el costo total con manejo de errores
    def calcular_total(self):
        try:
            # Solicitar días al usuario
            dias_str = input(f"Ingrese días para {self.__nombre}: ")
            # Convertir a entero (aquí puede ocurrir un ValueError)
            dias = int(dias_str)
            
            # Validar que los días no sean negativos
            if dias < 0:
                raise ValueError("La cantidad de días no puede ser negativa.")
            
            total = dias * self.__precio_dia
            print(f"Total a pagar por {self.__nombre}: ${total}")
            
        except ValueError as e:
            # Captura errores de letras en lugar de números o números negativos
            print(f"Error de entrada: {e}. Por favor use números enteros.")
        except Exception as e:
            # Captura cualquier otro error no previsto
            print(f"Ocurrió un error inesperado: {e}")

# Ejemplo de ejecución
martillo = HerramientaAlquiler("Martillo Hidráulico", 50)
martillo.calcular_total()